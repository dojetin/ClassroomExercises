package repaso;

public class Main {

	public static void main(String[] args) {
		Fecha fechita = new Fecha(1900, 2, 4);
		Fecha fechado = new Fecha(1995, 9, 15);
		Fecha facha = new Fecha(1998, 1, 1);
		Fecha ficha = new Fecha(1938, 4, 20);
		
		
		Persona listaTrabajadores[] = new Persona[10];
		
		for(int i =0; i<10;i++) {
			
			if(i==1){
				listaTrabajadores[i] = new Trabajador("Manuel", "Picaso", "Malaga", "79169816K", ficha, 66724650, "picaso@picota.com", 2, 180, 0, 950, "limpieza");
			} else if(i%2==0) {
				listaTrabajadores[i] =new Estudiante("Pablo Bruno", "Nobrega", "Lopez", "18815987D", fechado, 608439985, "nunoeselmejor@creetelo.com", 1, "DAM", 1, 10); 
			}else {
				listaTrabajadores[i] = new Profesor ("Antonio", "Rufo", "Apellido2", "35857368T", facha, 657883497, "rufo@rufo.rufo", 1, 160, 0, 1000, facha, "DAM", "Programacion", true);
				
			}
			//System.out.println(listaTrabajadores[i]);
		}
				
	for(int i =0; i<10;i++) {
			
			if(listaTrabajadores[i].getNombre().equalsIgnoreCase("Manuel")) {
				System.out.println(listaTrabajadores[i]);
			}
		}
				
		/*		
		Persona p1 = new Estudiante("Pablo Bruno", "Nobrega", "Lopez", "18815987D", fechado, 608439985, "nunoeselmejor@creetelo.com", 1, "DAM", 1, 10);
		System.out.println(p1.toString());
		
		Estudiante nuno = new Estudiante("Pablo Bruno", "Nobrega", "Lopez", "18815987D", fechado, 608439985, "nunoeselmejor@creetelo.com", 1, "DAM", 1, 10);
		System.out.println(nuno.toString());
		System.out.println("La nota media es:" + nuno.getNotamedia());
		/*
		
		Profesor Rufo = new Profesor ("Antonio", "Rufo", "Apellido2", "35857368T", facha, 657883497, "rufo@rufo.rufo", 1, 160, 0, 1000, facha, "DAM", "Programacion", true);
		System.out.println(Rufo.toString());
		
	
		Trabajador Picaso = new Trabajador("Manuel", "Picaso", "Malaga", "79169816K", ficha, 66724650, "picaso@picota.com", 2, 180, 0, 950, "limpieza");
		System.out.println(Picaso.toString());
		*/
	}

}
